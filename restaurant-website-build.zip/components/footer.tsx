import Link from "next/link"
import { Facebook, Instagram, Phone } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <Link href="#accueil" className="flex items-center gap-1 mb-4">
              <span className="font-serif text-2xl font-bold text-primary">SPOON</span>
              <span className="font-serif text-2xl italic text-secondary">Chef</span>
            </Link>
            <p className="text-muted-foreground leading-relaxed">
              {"L'expertise au service du Fast Food à la Carte. Qualité, saveur et passion depuis plus de 5 ans."}
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-serif text-lg font-bold text-foreground mb-4">Navigation</h4>
            <ul className="space-y-2">
              <li>
                <Link href="#accueil" className="text-muted-foreground hover:text-secondary transition-colors">
                  Accueil
                </Link>
              </li>
              <li>
                <Link href="#menu" className="text-muted-foreground hover:text-secondary transition-colors">
                  Menu
                </Link>
              </li>
              <li>
                <Link href="#apropos" className="text-muted-foreground hover:text-secondary transition-colors">
                  À Propos
                </Link>
              </li>
              <li>
                <Link href="#contact" className="text-muted-foreground hover:text-secondary transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-serif text-lg font-bold text-foreground mb-4">Contact</h4>
            <ul className="space-y-2">
              <li>
                <Link
                  href="https://wa.me/21625583914"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-secondary transition-colors flex items-center gap-2"
                >
                  <Phone className="w-4 h-4" />
                  +216 25 583 914
                </Link>
              </li>
              <li className="text-muted-foreground">
                Tunis, Tunisie
              </li>
              <li className="text-muted-foreground">
                Ouvert 7j/7
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="font-serif text-lg font-bold text-foreground mb-4">Suivez-nous</h4>
            <div className="flex gap-4">
              <Link
                href="https://www.facebook.com/p/Spoon-Chef-100063757015547/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-[#1877F2] transition-colors group"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5 text-muted-foreground group-hover:text-white transition-colors" />
              </Link>
              <Link
                href="https://www.instagram.com/spoon.chef"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-[#E4405F] transition-colors group"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5 text-muted-foreground group-hover:text-white transition-colors" />
              </Link>
              <Link
                href="https://wa.me/21625583914"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-[#25D366] transition-colors group"
                aria-label="WhatsApp"
              >
                <Phone className="w-5 h-5 text-muted-foreground group-hover:text-white transition-colors" />
              </Link>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-12 pt-8 border-t border-border text-center">
          <p className="text-muted-foreground text-sm">
            © 2025 Spoon Chef. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  )
}
