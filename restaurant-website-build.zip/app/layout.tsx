import type { Metadata } from 'next'
import { Playfair_Display, Poppins } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const playfair = Playfair_Display({ 
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
})

const poppins = Poppins({ 
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-poppins',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Spoon Chef | Fast Food à la Carte - Tunis',
  description: "L'expertise au service du Fast Food à la Carte. Fort de plusieurs années d'expérience, le Chef vous propose une cuisine à la carte savoureuse, préparée avec passion et des ingrédients de qualité.",
  keywords: 'restaurant, fast food, tunis, pizza, tacos, sandwich, shawarma, cuisine tunisienne',
  openGraph: {
    title: 'Spoon Chef | Fast Food à la Carte',
    description: "L'expertise au service du Fast Food à la Carte",
    type: 'website',
  },
}

export const viewport = {
  themeColor: '#0D0D0D',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fr" className={`${playfair.variable} ${poppins.variable} bg-background scroll-smooth`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
