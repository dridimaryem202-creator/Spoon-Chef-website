import Image from "next/image"
import { Award, Home, Clock } from "lucide-react"

export function AboutSection() {
  return (
    <section id="apropos" className="py-24 bg-background relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-secondary/5 rounded-full blur-3xl" />
      
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              <span className="text-foreground">Votre Chef,</span>
              <br />
              <span className="text-secondary">Votre Garantie</span>
            </h2>
            
            <p className="text-foreground/80 text-lg leading-relaxed mb-8">
              Bienvenue chez <span className="text-primary font-semibold">Spoon Chef</span>, 
              où la passion rencontre le savoir-faire. Notre chef, fort de plusieurs années 
              d&apos;expérience dans la restauration, a créé un concept unique : du fast food 
              préparé avec l&apos;exigence d&apos;un restaurant gastronomique.
            </p>
            
            <p className="text-foreground/80 text-lg leading-relaxed mb-10">
              Chaque plat est préparé à la commande avec des ingrédients frais et de qualité. 
              Que ce soit nos pizzas artisanales, nos tacos signature ou nos sandwichs gourmands, 
              vous retrouverez toujours la même qualité et le même goût authentique.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center p-4 bg-card rounded-xl border border-border hover:border-secondary/50 transition-colors">
                <Award className="w-8 h-8 text-secondary mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">5+</p>
                <p className="text-muted-foreground text-sm">Ans d&apos;expérience</p>
              </div>
              <div className="text-center p-4 bg-card rounded-xl border border-border hover:border-secondary/50 transition-colors">
                <Home className="w-8 h-8 text-secondary mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">100%</p>
                <p className="text-muted-foreground text-sm">Fait Maison</p>
              </div>
              <div className="text-center p-4 bg-card rounded-xl border border-border hover:border-secondary/50 transition-colors">
                <Clock className="w-8 h-8 text-secondary mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">7j/7</p>
                <p className="text-muted-foreground text-sm">Ouvert</p>
              </div>
            </div>
          </div>

          {/* Chef Image */}
          <div className="relative">
            <div className="relative aspect-square max-w-md mx-auto">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-full blur-3xl" />
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/702100268_1595355979266287_2081921397914744042_n%20%281%29-ZS9KCwTPAPGX3WIht9hUDoqR9A5cLE.jpg"
                alt="Spoon Chef Logo avec le Chef"
                fill
                className="object-cover rounded-full border-4 border-secondary/30"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
