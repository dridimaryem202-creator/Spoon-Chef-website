import Link from "next/link"
import { Phone, Clock, MapPin } from "lucide-react"

export function ContactSection() {
  return (
    <section id="contact" className="py-24 bg-background relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-secondary/5 rounded-full blur-3xl" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Commandez</span>{" "}
            <span className="text-secondary">Maintenant</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Contactez-nous pour passer votre commande ou pour plus d&apos;informations
          </p>
        </div>

        {/* Contact Content */}
        <div className="max-w-3xl mx-auto">
          {/* WhatsApp Button */}
          <div className="text-center mb-12">
            <Link
              href="https://wa.me/21625583914"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-[#25D366] hover:bg-[#20BD5A] text-white px-10 py-5 rounded-xl font-bold text-xl transition-all hover:scale-105 hover:shadow-xl hover:shadow-[#25D366]/30 animate-pulse-glow"
            >
              <Phone className="w-6 h-6" />
              +216 25 583 914
            </Link>
            <p className="mt-4 text-muted-foreground">
              Cliquez pour commander via WhatsApp
            </p>
          </div>

          {/* Info Cards */}
          <div className="grid sm:grid-cols-2 gap-6">
            <div className="bg-card border border-border rounded-xl p-6 text-center hover:border-secondary/50 transition-colors">
              <div className="w-14 h-14 rounded-full bg-secondary/20 flex items-center justify-center mx-auto mb-4">
                <Clock className="w-7 h-7 text-secondary" />
              </div>
              <h3 className="font-serif text-xl font-bold text-foreground mb-2">
                Horaires
              </h3>
              <p className="text-muted-foreground">Ouvert tous les jours</p>
              <p className="text-secondary font-semibold mt-1">12h00 - 23h00</p>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 text-center hover:border-secondary/50 transition-colors">
              <div className="w-14 h-14 rounded-full bg-secondary/20 flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-7 h-7 text-secondary" />
              </div>
              <h3 className="font-serif text-xl font-bold text-foreground mb-2">
                Localisation
              </h3>
              <p className="text-muted-foreground">Tunis, Tunisie</p>
              <p className="text-secondary font-semibold mt-1">Livraison disponible</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
