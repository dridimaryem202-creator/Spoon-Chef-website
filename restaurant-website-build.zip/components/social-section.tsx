import Link from "next/link"
import { Facebook, Instagram, Users } from "lucide-react"

export function SocialSection() {
  return (
    <section className="py-24 bg-card relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-secondary/5 rounded-full blur-3xl" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Suivez</span>{" "}
            <span className="text-secondary">Nous</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Rejoignez notre communauté et restez informé de nos nouveautés
          </p>
        </div>

        {/* Social Cards */}
        <div className="grid sm:grid-cols-2 gap-8 max-w-2xl mx-auto">
          {/* Facebook Card */}
          <Link
            href="https://www.facebook.com/p/Spoon-Chef-100063757015547/"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-background border border-border rounded-xl p-8 hover:border-secondary/50 transition-all hover:shadow-lg hover:shadow-secondary/10 group text-center"
          >
            <div className="w-16 h-16 rounded-full bg-[#1877F2]/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-[#1877F2]/20 transition-colors">
              <Facebook className="w-8 h-8 text-[#1877F2]" />
            </div>
            <h3 className="font-serif text-xl font-bold text-foreground mb-2 group-hover:text-secondary transition-colors">
              Facebook
            </h3>
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <Users className="w-4 h-4" />
              <span>700+ abonnés</span>
            </div>
          </Link>

          {/* Instagram Card */}
          <Link
            href="https://www.instagram.com/spoon.chef"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-background border border-border rounded-xl p-8 hover:border-secondary/50 transition-all hover:shadow-lg hover:shadow-secondary/10 group text-center"
          >
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#833AB4]/10 via-[#FD1D1D]/10 to-[#F77737]/10 flex items-center justify-center mx-auto mb-4 group-hover:from-[#833AB4]/20 group-hover:via-[#FD1D1D]/20 group-hover:to-[#F77737]/20 transition-colors">
              <Instagram className="w-8 h-8 text-[#E4405F]" />
            </div>
            <h3 className="font-serif text-xl font-bold text-foreground mb-2 group-hover:text-secondary transition-colors">
              Instagram
            </h3>
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <Users className="w-4 h-4" />
              <span>86 abonnés</span>
            </div>
          </Link>
        </div>

        {/* CTA */}
        <p className="text-center mt-10 text-secondary font-semibold text-lg">
          Rejoignez notre communauté pour des offres exclusives !
        </p>
      </div>
    </section>
  )
}
