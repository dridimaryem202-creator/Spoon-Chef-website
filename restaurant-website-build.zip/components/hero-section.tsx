import Image from "next/image"
import Link from "next/link"
import { ChefHat, UtensilsCrossed, Leaf } from "lucide-react"

export function HeroSection() {
  return (
    <section
      id="accueil"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/703222739_1595339452601273_5101143758500014622_n%20%281%29-TCoCbwtc7TyLnHCt4NopOSl3nv3M7Z.png"
          alt="Spoon Chef Restaurant"
          fill
          className="object-cover"
          priority
        />
        {/* Dark overlay with radial gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/70 to-background/40" />
        <div className="absolute inset-0 bg-radial-[at_70%_50%] from-secondary/10 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-32">
        <div className="max-w-2xl">
          {/* Main Heading */}
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6">
            <span className="text-foreground">{"L'EXPERTISE AU SERVICE"}</span>
            <br />
            <span className="text-foreground">DU FAST FOOD</span>
            <br />
            <span className="text-primary">À LA CARTE</span>
          </h1>

          {/* Subtext with quote styling */}
          <div className="relative pl-6 border-l-4 border-secondary mb-8">
            <p className="text-foreground/90 text-lg leading-relaxed">
              Fort de plusieurs années d&apos;
              <span className="text-primary">expérience</span>, le Chef vous propose une{" "}
              <span className="text-primary">cuisine à la carte</span> savoureuse, préparée
              avec passion et des ingrédients de qualité.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Link
              href="#menu"
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-lg font-semibold text-center transition-all hover:scale-105 hover:shadow-lg hover:shadow-primary/30"
            >
              Voir le Menu
            </Link>
            <Link
              href="https://wa.me/21625583914"
              target="_blank"
              rel="noopener noreferrer"
              className="border-2 border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground px-8 py-4 rounded-lg font-semibold text-center transition-all hover:scale-105"
            >
              Commander sur WhatsApp
            </Link>
          </div>
        </div>
      </div>

      {/* Bottom Feature Badges */}
      <div className="absolute bottom-0 left-0 right-0 bg-muted/90 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="flex items-center justify-center gap-3">
              <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center">
                <ChefHat className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <p className="font-semibold text-foreground">EXPÉRIENCE &</p>
                <p className="text-muted-foreground text-sm">SAVOIR-FAIRE</p>
              </div>
            </div>
            <div className="flex items-center justify-center gap-3">
              <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center">
                <UtensilsCrossed className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <p className="font-semibold text-foreground">CUISINE</p>
                <p className="text-muted-foreground text-sm">À LA CARTE</p>
              </div>
            </div>
            <div className="flex items-center justify-center gap-3">
              <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center">
                <Leaf className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <p className="font-semibold text-foreground">INGRÉDIENTS</p>
                <p className="text-muted-foreground text-sm">DE QUALITÉ</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
