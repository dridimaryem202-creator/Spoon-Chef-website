"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

const menuCategories = [
  { id: "sandwichs", label: "SANDWICHS" },
  { id: "tacos", label: "TACOS" },
  { id: "pizzas", label: "PIZZAS" },
]

const sandwichItems = [
  { name: "Jambon", large: "7.500", maxi: "9.000" },
  { name: "Escalope", large: "8.500", maxi: "11.000" },
  { name: "Shawarma", large: "8.500", maxi: "11.000" },
  { name: "Fromage", large: "7.000", maxi: "10.000" },
  { name: "Kebab", large: "9.500", maxi: "12.000" },
  { name: "Champignons", large: "8.000", maxi: "10.500" },
]

const tacosItems = [
  { name: "Tacos Spoon Chef", size: "Moyenne", price: "9.500" },
  { name: "Tacos Spoon Chef", size: "Maxi", price: "11.000" },
  { name: "Tacos Spoon Chef", size: "Familiale", price: "20.000" },
]

const pizzaItems = [
  { name: "4 Fromages", moyenne: "15", maxi: "20", familiale: "30" },
  { name: "Neptune", moyenne: "10.5", maxi: "16", familiale: "25" },
  { name: "Pepperoni", moyenne: "11", maxi: "17", familiale: "27" },
  { name: "Escalope", moyenne: "20", maxi: "25", familiale: "35" },
  { name: "4 Saisons", moyenne: "18", maxi: "22", familiale: "27" },
]

export function MenuSection() {
  const [activeCategory, setActiveCategory] = useState("sandwichs")

  return (
    <section id="menu" className="py-24 bg-card relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-secondary/5 rounded-full blur-3xl" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Notre</span>{" "}
            <span className="text-secondary">Menu</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Découvrez nos créations savoureuses, préparées avec passion et des ingrédients de qualité
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex justify-center gap-2 sm:gap-4 mb-12">
          {menuCategories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={cn(
                "px-4 sm:px-8 py-3 rounded-lg font-semibold text-sm sm:text-base transition-all",
                activeCategory === category.id
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/30"
                  : "bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground"
              )}
            >
              {category.label}
            </button>
          ))}
        </div>

        {/* Menu Content */}
        <div className="min-h-[400px]">
          {/* Sandwichs */}
          {activeCategory === "sandwichs" && (
            <div className="animate-fade-in-up">
              <p className="text-center text-secondary mb-8 text-lg">
                Pain au choix: <span className="font-semibold">Makloub • Libanais • Baguette farcie</span>
              </p>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {sandwichItems.map((item) => (
                  <div
                    key={item.name}
                    className="bg-background border border-border rounded-xl p-6 hover:border-secondary/50 transition-all hover:shadow-lg hover:shadow-secondary/10 group"
                  >
                    <h3 className="font-serif text-xl font-bold text-foreground mb-4 group-hover:text-secondary transition-colors">
                      {item.name}
                    </h3>
                    <div className="flex justify-between items-center">
                      <div className="text-center">
                        <p className="text-muted-foreground text-sm">Large</p>
                        <p className="text-secondary font-bold text-xl">{item.large} <span className="text-sm">DT</span></p>
                      </div>
                      <div className="w-px h-12 bg-border" />
                      <div className="text-center">
                        <p className="text-muted-foreground text-sm">Maxi</p>
                        <p className="text-secondary font-bold text-xl">{item.maxi} <span className="text-sm">DT</span></p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tacos */}
          {activeCategory === "tacos" && (
            <div className="animate-fade-in-up">
              <div className="text-center mb-8">
                <span className="inline-block bg-primary/20 text-primary px-4 py-2 rounded-full text-sm font-semibold">
                  Notre Spécialité
                </span>
              </div>
              <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
                {tacosItems.map((item, index) => (
                  <div
                    key={index}
                    className="bg-background border border-border rounded-xl p-6 hover:border-secondary/50 transition-all hover:shadow-lg hover:shadow-secondary/10 text-center group"
                  >
                    <h3 className="font-serif text-lg font-bold text-foreground mb-2 group-hover:text-secondary transition-colors">
                      {item.name}
                    </h3>
                    <p className="text-muted-foreground mb-4">{item.size}</p>
                    <p className="text-secondary font-bold text-3xl">{item.price} <span className="text-base">DT</span></p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Pizzas */}
          {activeCategory === "pizzas" && (
            <div className="animate-fade-in-up">
              <div className="mb-8">
                <div className="hidden sm:grid sm:grid-cols-4 gap-4 text-center text-muted-foreground font-semibold pb-4 border-b border-border">
                  <div />
                  <div>Moyenne</div>
                  <div>Maxi</div>
                  <div>Familiale</div>
                </div>
              </div>
              <div className="space-y-4">
                {pizzaItems.map((item) => (
                  <div
                    key={item.name}
                    className="bg-background border border-border rounded-xl p-6 hover:border-secondary/50 transition-all hover:shadow-lg hover:shadow-secondary/10 group"
                  >
                    <div className="grid sm:grid-cols-4 gap-4 items-center">
                      <h3 className="font-serif text-xl font-bold text-foreground group-hover:text-secondary transition-colors">
                        {item.name}
                      </h3>
                      <div className="text-center">
                        <span className="sm:hidden text-muted-foreground text-sm">Moyenne: </span>
                        <span className="text-secondary font-bold text-lg">{item.moyenne} <span className="text-sm">DT</span></span>
                      </div>
                      <div className="text-center">
                        <span className="sm:hidden text-muted-foreground text-sm">Maxi: </span>
                        <span className="text-secondary font-bold text-lg">{item.maxi} <span className="text-sm">DT</span></span>
                      </div>
                      <div className="text-center">
                        <span className="sm:hidden text-muted-foreground text-sm">Familiale: </span>
                        <span className="text-secondary font-bold text-lg">{item.familiale} <span className="text-sm">DT</span></span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  )
}
