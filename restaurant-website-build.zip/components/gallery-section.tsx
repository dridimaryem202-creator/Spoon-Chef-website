"use client"

import Image from "next/image"
import { useState } from "react"

const galleryItems = [
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/470087993_940234051347399_6995436124110311810_n-p6BsIC5nztAi0KeKEv4WNKYGnhjWoJ.jpg",
    alt: "Pizza Pepperoni",
    label: "Pizza Pepperoni",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/470224770_940233878014083_7336528531530695509_n-FCsquv361SEcyIk2zGc25jtzKfhvxH.jpg",
    alt: "Pizza 4 Fromages",
    label: "Pizza 4 Fromages",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/469945316_939983088039162_252260500906398374_n-XYvVqk8B2nUZKQBz1tx3EJjqE0sDwR.jpg",
    alt: "Calzone",
    label: "Calzone",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/470198850_939970178040453_8191237407978945819_n-KCuE7G90oy7WNooxvJUfZdbSVjWamE.jpg",
    alt: "Pasta",
    label: "Pasta",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/470165398_940631257974345_7328609452287906748_n-Qkvunv9AgRrFn2pdxKv4JDpU5hZ7K4.jpg",
    alt: "Pizza Spéciale",
    label: "Pizza Spéciale",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/470087572_940233954680742_587353473541765337_n-zGRQ4KFQTHzAwnkY1wy14AxUZxWTGH.jpg",
    alt: "Tacos avec Frites",
    label: "Tacos avec Frites",
  },
]

export function GallerySection() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)

  return (
    <section className="py-24 bg-background relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Nos</span>{" "}
            <span className="text-secondary">Créations</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Un aperçu de nos plats préparés avec amour et expertise
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryItems.map((item, index) => (
            <div
              key={index}
              className="relative aspect-square rounded-xl overflow-hidden cursor-pointer group"
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              <Image
                src={item.src}
                alt={item.alt}
                fill
                className={`object-cover transition-transform duration-500 ${
                  hoveredIndex === index ? "scale-110" : "scale-100"
                }`}
              />
              {/* Overlay */}
              <div
                className={`absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent transition-opacity duration-300 ${
                  hoveredIndex === index ? "opacity-100" : "opacity-0"
                }`}
              />
              {/* Label */}
              <div
                className={`absolute bottom-0 left-0 right-0 p-6 transition-all duration-300 ${
                  hoveredIndex === index
                    ? "translate-y-0 opacity-100"
                    : "translate-y-4 opacity-0"
                }`}
              >
                <h3 className="font-serif text-xl font-bold text-foreground">
                  {item.label}
                </h3>
              </div>
              {/* Border on hover */}
              <div
                className={`absolute inset-0 border-2 rounded-xl transition-colors duration-300 ${
                  hoveredIndex === index ? "border-secondary" : "border-transparent"
                }`}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
