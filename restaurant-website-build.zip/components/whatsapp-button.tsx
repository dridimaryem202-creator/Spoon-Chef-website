import Link from "next/link"
import { Phone } from "lucide-react"

export function WhatsAppButton() {
  return (
    <Link
      href="https://wa.me/21625583914"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#25D366] hover:bg-[#20BD5A] rounded-full flex items-center justify-center shadow-lg shadow-[#25D366]/30 hover:scale-110 transition-all animate-pulse-glow"
      aria-label="Commander sur WhatsApp"
    >
      <Phone className="w-6 h-6 text-white" />
    </Link>
  )
}
